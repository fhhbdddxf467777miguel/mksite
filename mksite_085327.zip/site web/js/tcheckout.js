// Gestion du panier sur la page panier.html
document.addEventListener('DOMContentLoaded', () => {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartItemsList = document.getElementById('cart-items-list');
    const cartEmpty = document.getElementById('cart-empty');
    const itemsCount = document.getElementById('items-count');
    const subtotalEl = document.getElementById('subtotal');
    const shippingEl = document.getElementById('shipping');
    const totalEl = document.getElementById('total');
    const checkoutBtn = document.getElementById('checkout-btn');
    
    // Afficher ou masquer le panier vide
    if (cart.length === 0) {
        cartEmpty.style.display = 'flex';
        cartItemsList.style.display = 'none';
        checkoutBtn.style.display = 'none';
        itemsCount.textContent = '0';
    } else {
        cartEmpty.style.display = 'none';
        cartItemsList.style.display = 'block';
        checkoutBtn.style.display = 'block';
        renderCartItems();
    }
    
    // Gestion des options de livraison
    document.querySelectorAll('input[name="delivery"]').forEach(radio => {
        radio.addEventListener('change', updateShipping);
    });
    
    // Rendu des articles du panier
    function renderCartItems() {
        cartItemsList.innerHTML = '';
        let subtotal = 0;
        
        cart.forEach((item, index) => {
            subtotal += item.price * item.quantity;
            
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                <div class="item-image">
                    <img src="${item.image}" alt="${item.name}">
                </div>
                <div class="item-details">
                    <h3>${item.name}</h3>
                    <p>${item.type === 'electronics' ? 'Électronique' : 'Service Web'}</p>
                    <p class="item-price">${formatPrice(item.price)} FCFA</p>
                </div>
                <div class="item-quantity">
                    <button class="quantity-btn minus" data-index="${index}">
                        <i class="fas fa-minus"></i>
                    </button>
                    <span>${item.quantity}</span>
                    <button class="quantity-btn plus" data-index="${index}">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
                <div class="item-subtotal">
                    ${formatPrice(item.price * item.quantity)} FCFA
                </div>
                <button class="item-remove" data-index="${index}">
                    <i class="fas fa-trash"></i>
                </button>
            `;
            
            cartItemsList.appendChild(cartItem);
        });
        
        itemsCount.textContent = cart.length;
        updateCartSummary(subtotal);
        
        // Ajouter les événements aux boutons
        document.querySelectorAll('.quantity-btn.minus').forEach(btn => {
            btn.addEventListener('click', decreaseQuantity);
        });
        
        document.querySelectorAll('.quantity-btn.plus').forEach(btn => {
            btn.addEventListener('click', increaseQuantity);
        });
        
        document.querySelectorAll('.item-remove').forEach(btn => {
            btn.addEventListener('click', removeItem);
        });
    }
    
    // Mettre à jour le résumé du panier
    function updateCartSummary(subtotal) {
        const shipping = document.querySelector('input[name="delivery"]:checked').id === 'express' ? 5000 : 0;
        const total = subtotal + shipping;
        
        subtotalEl.textContent = `${formatPrice(subtotal)} FCFA`;
        shippingEl.textContent = shipping > 0 ? `${formatPrice(shipping)} FCFA` : 'Gratuit';
        totalEl.textContent = `${formatPrice(total)} FCFA`;
        
        // Mettre à jour le localStorage pour le résumé
        localStorage.setItem('cartSummary', JSON.stringify({ subtotal, shipping, total }));
    }
    
    // Mettre à jour les frais de livraison
    function updateShipping() {
        const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        updateCartSummary(subtotal);
    }
    
    // Diminuer la quantité
    function decreaseQuantity(e) {
        const index = e.target.closest('.quantity-btn').dataset.index;
        if (cart[index].quantity > 1) {
            cart[index].quantity--;
            localStorage.setItem('cart', JSON.stringify(cart));
            renderCartItems();
            updateCartCount();
        }
    }
    
    // Augmenter la quantité
    function increaseQuantity(e) {
        const index = e.target.closest('.quantity-btn').dataset.index;
        cart[index].quantity++;
        localStorage.setItem('cart', JSON.stringify(cart));
        renderCartItems();
        updateCartCount();
    }
    
    // Supprimer un article
    function removeItem(e) {
        const index = e.target.closest('.item-remove').dataset.index;
        cart.splice(index, 1);
        localStorage.setItem('cart', JSON.stringify(cart));
        
        if (cart.length === 0) {
            cartEmpty.style.display = 'flex';
            cartItemsList.style.display = 'none';
            checkoutBtn.style.display = 'none';
            itemsCount.textContent = '0';
        } else {
            renderCartItems();
        }
        
        updateCartCount();
    }
    
    // Formater le prix
    function formatPrice(price) {
        return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    }
});

// Gestion de la page de paiement (checkout.html)
document.addEventListener('DOMContentLoaded', () => {
    const cartSummary = JSON.parse(localStorage.getItem('cartSummary')) || { subtotal: 0, shipping: 0, total: 0 };
    
    // Mettre à jour le résumé de la commande
    document.getElementById('summary-subtotal').textContent = `${formatPrice(cartSummary.subtotal)} FCFA`;
    document.getElementById('summary-shipping').textContent = 
        cartSummary.shipping > 0 ? `${formatPrice(cartSummary.shipping)} FCFA` : 'Gratuit';
    document.getElementById('summary-total').textContent = `${formatPrice(cartSummary.total)} FCFA`;
    
    // Validation du formulaire
    const form = document.getElementById('customer-info');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Validation du numéro de téléphone camerounais
        const phone = document.getElementById('phone').value;
        if (!/^(6|2)(2|3|[5-9])[0-9]{7}$/.test(phone)) {
            showNotification('Veuillez entrer un numéro de téléphone valide (format camerounais)');
            return;
        }
        
        // Sauvegarder les informations client
        const customerInfo = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            phone: phone,
            address: document.getElementById('address').value,
            city: document.getElementById('city').value,
            region: document.getElementById('region').value
        };
        
        localStorage.setItem('customerInfo', JSON.stringify(customerInfo));
        
        // Rediriger vers la page de paiement
        window.location.href = 'checkout-step2.html'; // À créer dans les prochaines étapes
    });
    
    // Formater le prix
    function formatPrice(price) {
        return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    }
    
    // Afficher une notification
    function showNotification(message) {
        // Implémentation similaire à cart.js
    }
});

// Gestion de la page de contact
document.addEventListener('DOMContentLoaded', () => {
    const contactForm = document.getElementById('contactForm');
    
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Envoyer le message (simulé)
        showNotification('Votre message a été envoyé avec succès!');
        contactForm.reset();
        
        // Envoyer une notification par email (serait implémenté avec un backend)
    });
    
    // Gestion des FAQ
    document.querySelectorAll('.faq-question').forEach(question => {
        question.addEventListener('click', () => {
            const answer = question.nextElementSibling;
            const icon = question.querySelector('i');
            
            if (answer.style.maxHeight) {
                answer.style.maxHeight = null;
                answer.style.padding = '0 20px';
                icon.classList.remove('fa-chevron-up');
                icon.classList.add('fa-chevron-down');
            } else {
                answer.style.maxHeight = answer.scrollHeight + 'px';
                answer.style.padding = '20px';
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-up');
            }
        });
    });
});